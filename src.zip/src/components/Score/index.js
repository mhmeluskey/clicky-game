export { default } from "./Score";
